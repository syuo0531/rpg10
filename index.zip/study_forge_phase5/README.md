# STUDY FORGE — PHASE 5

PHASE 4 の全機能を維持し、QUEST / ACHIEVEMENT / COLLECTION 拡張を追加したブラウザゲーム版です。

## PHASE 5
- DAILY QUEST 5種
- WEEKLY QUEST 3種
- ACHIEVEMENT 10種
- 報酬受け取り機能
- Weekly reward chest（RARE / EPIC以上の武器）
- 120武器図鑑カテゴリ進捗
- 敵図鑑 / BESTIARY
- 素材コレクション表示
- 日次・週次自動リセット

## GitHub Pages
`index.html` をリポジトリのルートに置き、Settings → Pages → main / root で公開してください。

既存の localStorage セーブキーを維持しているため、過去PHASEから進行を引き継げます。
